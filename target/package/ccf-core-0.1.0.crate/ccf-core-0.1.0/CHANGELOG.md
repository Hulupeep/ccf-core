# Changelog

## [Unreleased]

### Added
- `ccf-core` crate skeleton: `no_std`, BSL 1.1, CI, embedded target build (#47)
